getwd()
setwd("C:\\Users\\user\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\Lab_5")
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
attach(Delivery_Times)
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)
histogram<-hist(X1,main = "Histogram for Driver Time",breaks = seq(20,70,length = 8),right = FALSE)
breaks<-round(histogram$breaks)
freq<-histogram$counts
mids<-histogram$mids
classes<-c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[", breaks[i], ".", breaks[i+1], ")")
}
classes
cbind(Classes = classes,Frequency = freq)
cum.freq<-cumsum(freq)
cum.freq
new<-c()
for(i in 1:length(breaks)){
  if (i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
new
plot(breaks, new,type = 'o',main = "Cumalative Frequancy Polygon for Driver Time",xlab="Driver time",ylab ="Cumalative Frequency",ylim = c(0, max(cum.freq)))
