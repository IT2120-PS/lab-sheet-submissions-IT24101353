getwd()
setwd("C:\\Users\\IT24101353\\Desktop\\IT24101353_Lab6")
#Q1
#Binomal distribution
pbinom(46, 50, 0.85,lower.tail = FALSE)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15, 12)
